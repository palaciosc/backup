(function(){
	'use strict';
	//Controlador del Home
	angular.module('ereaHubApp')
		.controller('MsgCtrl')
		.controller('HomeCtrl', function (authService, $rootScope, $q, $scope, $http, $sce, $location) {
			var vm = this;
			vm.auth = authService;
			vm.profile;

			if(!authService.isAuthenticated()){
				$location.path('/login');
				//authService.login();
				return;
			} else {
				console.log('Authenticated!!!');
			}

			function getProfile() {
				var deferred = $q.defer();
				if (authService.getCachedProfile()) {
					deferred.resolve(authService.getCachedProfile());
				} else {
					authService.getProfile(function(err, profile) {
						if(!err) {
							deferred.resolve(profile);
						}
					});
				}

				return deferred.promise;
			}

			function getMetadata(userId) {
				var idToken = localStorage.getItem('id_token');
				var req = {
					method: 'GET',
					url: 'https://erea.auth0.com/api/v2/users/'+ userId +'?fields=user_metadata&include_fields=true',
					headers: {
						Authorization: 'Bearer '+ idToken
					}
				}

				return $http(req);
			}

			var promise = getProfile();
			promise.then(function (profile) {
				vm.profile = profile;

				try{ //Se agregan los atributos del usuario a Slaask
			    	console.log(profile.name);
			    	_slaask.identify("DIU-"+profile.name, {
						user_id: profile.sub,
						email: profile.email,
						enterprise: 'diunsa',
						firstName: profile.name
					});
					_slaask.init('d59e78e769f6bbcef160fbdadb687a00');
			    }catch(err){
			    	console.log(err);
			    }

				getMetadata(vm.profile.sub).then(function(res) {
					authService.setUserMetadata(res.data.user_metadata);
					$http.get('/api/url').success(function(data){
						$scope.dashboards = res.data.user_metadata.hubs[data.hub].dashboards;
						$scope.applications = res.data.user_metadata.hubs[data.hub].apps;
					
						//Funcion que hace valido el link para hacer el login en SISENSE
						$scope.trustSrc = function(src) {
							return $sce.trustAsResourceUrl(src);
						}
						$scope.go = function(target) {
							$location.path(target);
						}
						//Se obtiene la data de los dashboards.
						//Email necesario para obtener el enlace para hacer el Single Sign On.
						var email = vm.profile.email;

						var user_name = "";
							if(vm.profile.name){
								user_name = vm.profile.name;
							}else if(vm.profile.user_metadata){
								user_name = vm.profile.user_metadata.name;
						}else{
							user_name = email;
						}
						
						$scope.user_name = user_name;
						$scope.initials = vm.profile.given_name.substring(0,1);

						$scope.message = 'Hola, ' + user_name + '!';

						var categories_list = [];
						var subcategories_list = [];
						var subcatcat_list = [];
						for(var i in $scope.dashboards)
						{
							//Llenar lista de categorias
							for(var j in $scope.dashboards[i].categories)
							{
								if(categories_list.indexOf($scope.dashboards[i].categories[j]) == -1)
								{
									categories_list.push($scope.dashboards[i].categories[j]);
								}
							}
							//Llenar lista de subcategorias
							for(var j in $scope.dashboards[i].subcategories)
							{
								var index = subcategories_list.indexOf($scope.dashboards[i].subcategories[j]);
								//Si no existia
								if(index == -1 && $scope.dashboards[i].subcategories[j]!='')
								{
									subcategories_list.push($scope.dashboards[i].subcategories[j]);
									subcatcat_list.push($scope.dashboards[i].categories);
								}
								//Si ya existia
								else if (index!=-1)
								{
									for(var k in $scope.dashboards[i].categories)
									{
										if(subcatcat_list[index].indexOf($scope.dashboards[i].categories[k]) == -1)
										{
											subcatcat_list[index].push($scope.dashboards[i].categories[k]);
										}								
									}
								}
							}
						}
						//Generar categorias
						$scope.categories = [];
						$scope.categories.push({id:'1', name:'Todos'});
						for (var i = 0; i < categories_list.length; i++) {
							$scope.categories.push({id:(i+2).toString(), name:categories_list[i]})
						}
						
						//Order la lista
						$scope.categories.sort(function(a, b){
							if (a.name < b.name) return -1;
							if (a.name > b.name) return 1;
							return 0;
						});

						//Generar subcategorias
						$scope.subcategories = [];
						$scope.subcategories.push({id:'1', name:'Todos los sectores', categories:categories_list});
						for (var i = 0; i < subcategories_list.length; i++) {
							$scope.subcategories.push({id:(i+2).toString(), name:subcategories_list[i], categories:subcatcat_list[i]})
						}
						

						$scope.selected = { value: $scope.categories[0] };

						//Filtrar on pageload
						for (var i = 0; i < $scope.categories.length; i++) {
							if($scope.categories[i].name=='Principal')
							{
								$scope.selected = { value: $scope.categories[i] };
								break;
							}
						}

						$scope.selectedsubcategory = { value: $scope.subcategories[0] };
					});

					$scope.filterHasCategory = function(item){
						if($scope.selected.value.id == 1)
							return true;
						else if(item.categories !=null && item.categories.includes($scope.selected.value.name))
							return true;
						else
							return false;
					};

					$scope.filterHasSubCategory = function(item){
						if($scope.selectedsubcategory.value.id == 1)
							return true;
						else if(item.categories !=null && item.subcategories.includes($scope.selectedsubcategory.value.name))
							return true;
						else
							return false;
					};

				});
			});
		})
		.filter('orderObjectBy', function(){
			return function(input, attribute) {
				if (!angular.isObject(input)) return input;

				var array = [];
				for(var objectKey in input) {
					array.push(input[objectKey]);
				}

				array.sort(function(a, b){
					a = parseInt(a[attribute]);
					b = parseInt(b[attribute]);
					return a - b;
				});
				return array;
			}
		});
})();
