(function(){
	'use strict';
	//Controlador del Home
	angular.module('ereaHubApp')
		.controller('MenuCtrl', function ($scope, $location) {

			$scope.go = function (target) {
				$location.path(target);
			};
		}); 
})();