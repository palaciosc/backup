(function(){
	'use strict';
	//Controlador del Home
	angular.module('ereaHubApp')
		.controller('MsgCtrl', function ($scope, angularAuth0) {
		  $scope.message = {text: ''};
		  $scope.errorMessage = {text: ''};
		});
})();
