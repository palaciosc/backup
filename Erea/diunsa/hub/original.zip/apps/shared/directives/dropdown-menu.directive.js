(function () {
  
	angular
		.module('ereaHubApp')
		.directive('dropdownMenu', dropdownMenu);

    function dropdownMenu($document){
		return {
			restrict: 'A',
			link: function(scope, element, attrs){
				element.on('click', function(){
					if (element.hasClass('dropdown-active')) {
						element.removeClass('dropdown-active');
						element.removeClass('dropdown-active-right')
					} else {
						element.addClass('active-recent');
					}
					var ul = element[0].querySelector('ul.dropdown-content');
					element.toggleClass('dropdown-active');
	
					if(ul.getBoundingClientRect().right > window.innerWidth){
						element.addClass('dropdown-active-right');
					}


				});
				
				$document.on('click', function() {
					if(!element.hasClass('active-recent')) {
						element.removeClass('dropdown-active');
						element.removeClass('dropdown-active-right')
					}
					element.removeClass('active-recent');
			});

			window.addEventListener('blur',function(){
	      if(document.activeElement.id == 'iframe'){
	         if(!element.hasClass('active-recent')) {
						element.removeClass('dropdown-active');
						element.removeClass('dropdown-active-right')
					}
					element.removeClass('active-recent');
	      }
			});

			}
		};
	};

})();	

	