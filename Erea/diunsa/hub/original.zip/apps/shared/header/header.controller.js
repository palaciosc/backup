(function(){

	'use strict';

	HeaderController.$inject = ['$scope', '$http', '$sce', 'auth', '$location'];
	
	function HeaderController($scope, $http, $sce, auth, $location){
		  $scope.auth = auth;
		  $scope.dashboards = auth.profile.user_metadata.dashboards;
		  $scope.applications = auth.profile.user_metadata.apps;
		  $scope.user_name = "";

		  //Funcion que hace valido el link para hacer el login en SISENSE
		  $scope.trustSrc = function(src) {
		    return $sce.trustAsResourceUrl(src);
		  }
		  //Se obtiene la data de los dashboards.
		  //Email necesario para obtener el enlace para hacer el Single Sign On.
		  $scope.email = auth.profile.email;

		  if(auth.profile.name){
		    $scope.user_name = auth.profile.name;
		  }
		  else if(auth.profile.user_metadata){
		    $scope.user_name = auth.profile.user_metadata.name;
		  }
		  else{
		    $scope.user_name = $scope.email;
		  }
		  $scope.initials = auth.profile.given_name.substring(0,1);
		  $scope.appsMenu = [];
			var obj = [];
			for (var i = 0; i < $scope.applications.length; i++) {

				//if object size is 2 add one more and push it to the
				//array
				if (  Object.keys(obj).length >= 2) {
					obj.push(
					{ 
						name: $scope.applications[i].initials,
						link: $scope.applications[i].url,
						description: $scope.applications[i].app_name
					}
					);
					$scope.appsMenu.push(obj);
					obj = [];
				} else {
					obj.push(
					{ 
						name: $scope.applications[i].initials,
						link: $scope.applications[i].url,
						description: $scope.applications[i].app_name
					}
					);
				}
				//check if there are pending apps to push to the array
				//check limit of apps menu to two items
				if (i === $scope.applications.length - 1 
				    && Object.keys(obj).length !== 0 
				    && $scope.appsMenu.length < 2) {
					$scope.appsMenu.push(obj);
					obj = [];
				}
			}
			
			if ($scope.applications.length > 6) {
				$scope.apps = true;
			}

			$scope.dashMenu = [];
			var obj = [];
			for (var i = 0; i < $scope.dashboards.length; i++) {
				
				//if object size is 2 add one more and push it to the
				//array
				if (  Object.keys(obj).length >= 2) {
					obj.push(
					{ 
						name: $scope.dashboards[i].initials,
						link: $scope.dashboards[i].type !== 'SISENSE' ? $scope.dashboards[i].url : '#/dashboard/'+$scope.dashboards[i].slug+'/'+$scope.dashboards[i].menu.default,
						type: $scope.dashboards[i].type,
						description: $scope.dashboards[i].name
					}
					);
					$scope.dashMenu.push(obj);
					obj = [];
				} else {

					obj.push(
					{ 
						name: $scope.dashboards[i].initials,
						link: $scope.dashboards[i].type !== 'SISENSE' ? $scope.dashboards[i].url : '#/dashboard/'+$scope.dashboards[i].slug+'/'+$scope.dashboards[i].menu.default,
						type: $scope.dashboards[i].type,
						description: $scope.dashboards[i].name

					}
					);
				}
				//check if there are pending apps to push to the array
				//check limit of apps menu to two items
				if (i === $scope.dashboards.length - 1 
				    && Object.keys(obj).length !== 0 
				    && $scope.dashMenu.length < 2) {
					$scope.dashMenu.push(obj);
					obj = [];
				}
			}
			if ($scope.dashboards.length > 6) {
				$scope.dash = true;
			}

		  $scope.go = function(target){
		  	if (target.includes("#"))
		  		target = target.substring(target.indexOf('/'));
		  	$location.path(target);
		  };

	}

	angular
	.module('ereaHubHeader')
	.controller('HeaderController', HeaderController);
})();
