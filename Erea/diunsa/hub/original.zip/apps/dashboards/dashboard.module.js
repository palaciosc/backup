/****************************************************************************
* Nombre: module.js
* Descripción: Este archivo está destinado para la creación y la configuración
* de las rutas de la App.
*****************************************************************************/
(function(){
    'use strict';
    var dash = angular.module('ehDashboard');
    dash.config(function ($routeProvider) {
        $routeProvider
        .when('/dashboard/:slug/:dashboard_id',  {
            templateUrl: 'apps/dashboards/layouts/dashboard.template.html',
            requiresLogin: true,
            controller: 'DashboardCtrl',
            controllerAs: 'vm',
            css: ''
        })
        .when('/dashboard/:slug/',  {
            templateUrl: 'apps/dashboards/layouts/dashboard.template.html',
            requiresLogin: true,
            controller: 'DashboardCtrl',
            controllerAs: 'vm',
            css: ''
        });; 

    });
    dash.run(["$http", "$rootScope", function($http, $rootScope) {
        // access $http and routeSegmentProvider here
        $http.get('/api/url').success(function(data){
        $rootScope.api_host = data;
        })
    }]);

})();
