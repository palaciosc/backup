var dotenv = require('dotenv').config()
var express = require('express');
var app = express();
var jwt = require('jwt-simple');
var url = require('url');


var bodyParser = require('body-parser');
app.use( bodyParser.json() );       // to support JSON-encoded bodies
app.use(bodyParser.urlencoded({     // to support URL-encoded bodies
  extended: true
})); 


app.use(express.static('.', { maxAge: 4 * 60 * 60 * 1000 /* 2hrs */ }))

/*
*   Descripcion:Funcion del API que te permite obtener un enlace con los parametros necesarios
*               para realizar un Single Sign On.
*   Parametros: Email para utenticarse en SISENSE, si el usuario no existe creara un 
*               usuario como viewer por defecto.
*/
app.post('/api/autenticar', function(req, res){
	var email = 'mf.bautista@ereaconsulting.com';
	var subdomain = 'data.ereaxp.com';
	var shared_key = '9d7f39cb857b94da5fd5cb0a6600695aa2f9241c234aa4f800e3bc91e6796d1a';

	var payload = {
	    iat: (parseInt(new Date().getTime() / 1000)),
	    sub: email
	    //exp: ((new Date().getTime() + 1 * 60000 )/ 1000) // expires in 1 minute.
	    // aud: ["sisense"]
	};

	// Se aplica el encode con el payload and clave secreta compartida.
	var token = jwt.encode(payload, shared_key);
	var redirect = 'http://data.ereaxp.com/jwt?jwt=' + token;
	var query = url.parse(req.url, true).query;

    //Se obtiene el lugar a donde se hara el redirect despues de haber hecho el Sign In.
	if (query['return_to']) {
	    redirect += '&return_to=' + encodeURIComponent(query['return_to']);
	}
	response = {"url": redirect};

    //Envia la respuesta, en formato json.
	res.json(response);
});

app.get("/api/url", function(req, res) {
    var response = {
    	"env":process.env.API_HOST,
    	"hub":process.env.hub
	};
    res.json(response);
});

app.set('port', process.env.PORT || 3000);
module.exports = app;

