function clickTab(element){
	if(!jQuery(element).hasClass("active")){
		jQuery("a",".active").css("border-bottom-color","transparent");
		jQuery(".active").toggleClass("active");
		jQuery(element).toggleClass("active");
		jQuery("a", element).css("border-bottom-color",jQuery(element).attr("erea-bb-color"));
		if(jQuery(element).parent().hasClass("dropdown-menu")){
			jQuery(element).parent().parent().toggleClass("active");
		}
	}

	iframe = jQuery("a", element).attr("href");
	jQuery("iframe.active").toggleClass("active");
	jQuery(iframe).toggleClass("active");
	if(typeof jQuery(iframe).attr("src") == "undefined")
		jQuery(iframe).attr("src", "http://data.ereaxp.com/app/main#/dashboards/"+iframe.substring(1)+"?embed=true")
}

function clickDropdown(element){
	if(!jQuery(element).hasClass("open")){
		jQuery(".dropdown-menu", jQuery(".open")).hide();
		jQuery(".open").toggleClass("open");
	}
	jQuery(element).toggleClass("open");
	if(jQuery(element).hasClass("open"))
		jQuery(".dropdown-menu", element).show();
	else
		jQuery(".dropdown-menu", element).hide();
}
