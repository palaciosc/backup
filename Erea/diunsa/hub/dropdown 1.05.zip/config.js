/****************************************************************************
* Nombre: config.js
* Descripción: Este archivo está destinado para la configuración de cada HUB
*****************************************************************************/
var config = {
	//Servicios
	idGoogleAnalytics : 'UA-102314410-1',
	idClientAuth0 : 'w7KtDpsxuYhHlq30DNhnGEnLu09DoUtV',
	idSlaask: 'd59e78e769f6bbcef160fbdadb687a00',
	domain : 'erea.auth0.com',
	
	//Login
	companyName: 'Diunsa',
	srcLogo: 'public/images/logoDiunsa.png',
	helpMail: 'diunsa@ereaconsulting.com',
	googleAuthentication:false,
	usernamePasswordAuthentication: true,
	hub: 'diunsa',
};
