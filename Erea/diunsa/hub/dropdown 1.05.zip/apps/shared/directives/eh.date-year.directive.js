(function () {
  
	angular
		.module('ereaHubApp')
		.directive('dateYearSelector', dateYearSelector);

    function dateYearSelector(){
		return {
			restrict: 'E',
			scope: {
				changeDate: '&',
				year: '='
			},
			templateUrl: 'apps/shared/layouts/year-picker.html',
			link: function(scope, element, attrs){
				var today = new Date();
				if (scope.year==undefined){
					scope.year = today.getFullYear();	
				}

				scope.previous = function(){
					scope.year--;
					scope.changeDate({year: scope.year});
				};

				scope.next = function(){
					scope.year++;
					scope.changeDate({year: scope.year});
				};
			}
		};
	};

})();	

	