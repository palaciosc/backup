/**
* @desc order directive that selects country
* @example <div acme-order-calendar-range></div>
*/
(function () {
  
  angular
    .module('ereaHubApp')
    .directive('countrySelector', selectCountry);

  function selectCountry() {
    /* implementation details */
    var directive = {
        scope: {
          'currentCountry': '=',
          'onUpdate': '&'

        },
        templateUrl: 'apps/shared/directives/country-select.html',
        restrict: 'EA',
        link: linkFunc,
      };
    return directive;
    function linkFunc(scope, el, attr, ctrl) {
      
    }

  }

})();