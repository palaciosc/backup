(function(){
	'use strict';
	//Controlador del Home
	angular.module('ereaHubApp')
	.controller('LoginCtrl', EHLoginCtrl);

	EHLoginCtrl.$inject = ['$scope', 'authService','$location', 'store', '$timeout'];
	function EHLoginCtrl($scope, authService, $location, store, $timeout) {
	  $scope.user = '';
	  $scope.pass = '';
	  $scope.email= '';

	  if(authService.isAuthenticated()){
	    $location.path('/');
	    return;
	  }

	  function onLoginSuccess(profile, token) {
	  	//if(ga)
	  	//{
	  	//	ga('set', 'userId', profile.user_id); //Se envia el user_id a google analytics.
	  	//}
	    $scope.message = '';
	    $scope.errorMessage.text = '';
	    store.set('profile', profile);
	    store.set('token', token);
	    $rootScope.first_time = true;
	    $location.path('/');
	    $scope.loading = false;
	  }

	  function onLoginFailed(error) {
	  	console.log(error.description)
	  	var code = error.code||'';

	    $scope.message = '';
	    if(code == 'user_exists')
	    	$scope.errorMessage.text = 'El usuario ya existe.';
	    else if(code == 'username_exists')
	    	$scope.errorMessage.text = 'El nombre de usuario ya existe.';
	    else if(code == 'invalid_user_password' || code == 'invalid_grant')
	    	$scope.errorMessage.text = 'Credenciales inválidas.';
	    else if(code == 'too_many_attempts')
	    	$scope.errorMessage.text = 'Tu cuenta ha sido bloqueada por múltiples intentos consecutivos. Se te ha enviado un correo con las intrucciones de como desbloquearlo.';
	    else if(code == 'mfa_required')
	    	$scope.errorMessage.text = 'Se requiere el codigo MFA para la autenticación.';
	    else if(code == 'mfa_registration_required')
	    	$scope.errorMessage.text = 'Se requiere el codigo MFA para la autenticación.';
	    else if(code == 'mfa_invalid_code')
	    	$scope.errorMessage.text = 'El código MFA ingresado es inválido.';
	    else if(code == 'PasswordStrengthError')
	    	$scope.errorMessage.text = 'La contraseña no cumple con con los requisitos necesarios.';
	    else if(code == 'PasswordHistoryError')
	    	$scope.errorMessage.text = 'La contraseña ya había sido utilizada anteriormente.';
	    else if(code == 'mfa_invalid_code')
	    	$scope.errorMessage.text = 'El código MFA ingresado es inválido.';
	    else if(code == 'access_denied')
	    	$scope.errorMessage.text = error.details.error_description||'Accesso denegado. Pónganse en contacto con nosotros.';
	    else if(code == 'unauthorized'){
	    	$scope.errorMessage.text = 'Su usuario ha sido bloqueado. Póngase en contacto con nosotros.';
	    }else 
	    	$scope.errorMessage.text = error.message||'Error desconocido.';
	    $scope.loading = false;
	  }

	  $scope.reset = function() {
	    authService.reset({
	      email: 'hello@bye.com',
	      password: 'hello',
	      connection: 'Username-Password-Authentication'
	    });
	  };

	  $scope.submit = function () {
	    $scope.message = 'loading...';
	    $scope.loading = true;
	    $scope.errorMessage.text = '';
	    console.log('Scope', $scope);
	    var promise = authService.login(
	      {
	      connection: 'Username-Password-Authentication',
	      username: $scope.email,
	        password: $scope.pass
	      }
	    );
	    promise.then(
	    	function (authResult){
	    		$scope.errorMessage.text = '';
	    	},
	    	onLoginFailed
	    );
	  };

	  $scope.doGoogleAuthWithPopup = function () {

	    $scope.message = 'loading...';
	    $scope.loading = true;
		
		authService.login({
			connection: 'google-oauth2'
		});

	    // angularAuth0.popup.signin({
	    //   // popup: true,
	    //   connection: 'google-oauth2',
	    //   scope: 'openid name email'
	    // }, onLoginSuccess, onLoginFailed);
	  };

	};
})();