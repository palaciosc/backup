(function(){
	'use strict';

	//Controlador del Logout
	angular.module('ereaHubApp')
		.controller('LogoutCtrl', function (authService, $scope, $location, store, $window) {
			$window.ga('send', 'pageview', { 'sessionControl': 'end'}); //SE detiene la sesion forzadamente.
			authService.logout();
			$scope.$parent.message = '';
			// store.remove('profile');
			// store.remove('token');
			$location.path('/');
		});
})();
