(function(){
	'use strict';
	//Controlador de los Dashboards
	angular.module('ereaHubApp')
		.controller('DashboardsCtrl', DashboardCtrl);

	DashboardCtrl.$inject = ['authService', '$scope', '$location', '$q'];
	function DashboardCtrl(authService, $scope, $location, $q) {
		var vm = this;
		vm.auth = authService;
		vm.profile;

		if(!authService.isAuthenticated()){
			// $location.path('/login');
			authService.login();
			return;
		} else {
			console.log('Authenticated!!!');
		}

		var user_metadata = authService.getUserMetadata();
		var profile = authService.getCachedProfile();
		$scope.dashboards = user_metadata.hubs[data.hub].dashboards;
		//Funcion que hace valido el link para hacer el login en SISENSE
		$scope.trustSrc = function(src) {
			return $sce.trustAsResourceUrl(src);
		}
		$scope.go = function(target) {
			$location.path(target);
		}
		//Se obtiene la data de los dashboards.
		//Email necesario para obtener el enlace para hacer el Single Sign On.
		var email = profile.email;

		var user_name = "";
		if(profile.name){
			user_name = profile.name;
		} else if(profile.user_metadata){
			user_name = profile.user_metadata.name;
		}else{
			user_name = email;
		}
		$scope.user_name = user_name;
		$scope.initials = profile.given_name.substring(0,1);
		$scope.message = 'Hola, ' + user_name + '!';
		
	};
})();
