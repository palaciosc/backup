/****************************************************************************
* Nombre: modules.js
* Descripción: Este archivo está destinado para listar todos los módulos
* para cada aplicación
*****************************************************************************/
angular.module('ehDashboard', ['ui.select', 'ngSanitize']);