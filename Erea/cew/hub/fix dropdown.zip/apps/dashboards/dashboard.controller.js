/****************************************************************************
* Nombre: hrControllers.js
* Descripción: Este archivo está destinado para los controladores de HR
*****************************************************************************/

(function(){
	var dash = angular.module('ehDashboard');
	
	//Controladores de la aplicación
	dash.controller('DashboardCtrl', AppCtrl);
	dash.controller('DashMenuCtrl', DashMenuCtrl);

	//Definicion de los controladores
	AppCtrl.$inject = ['$http','$scope','$sce', '$location', '$routeParams', 'authService'];
	function AppCtrl($http, $scope, $sce,  $location, $routeParams, authService){

		if(!authService.isAuthenticated()){
			$location.path('/login');
			//authService.login();
			return;
		} else {
			console.log('Authenticated!!!');
		}

		var user_metadata = authService.getUserMetadata();
		var profile = authService.getCachedProfile();
		$scope.profile = profile;
		$scope.email = profile.email;
		var vm = this;

		//Variables
		vm.overlay = false;
		
		//Funciones
		vm.go = function(target){
			$location.path(target);
		}

		if($routeParams.dashboard_id){
			
			var url = "https://sso.ereahub.com/api/v1/sisense/sso?username="+$scope.email+"&return_to=https://data.ereaxp.com/app/main%23/dashboards/"+$routeParams.dashboard_id+"%3Fembed%3Dtrue%26t%3Dtrue";
	    
		    $http.get(url).then(
		      function(response){
		      	vm.actualDashboard = $sce.trustAsResourceUrl(response.data);

				if(ga)
				{
					ga('set', 'dimension1', $routeParams.slug);
					ga('set', 'dimension2', $routeParams.dashboard_id);
				}

		      	return "SUCCESS";
		        },
		      function(response){
		         
		          return "FAIL";
		        }
		      );
		}else{
			
			vm.actualDashboard = "";
		}

	};

	//Controller for dashboards menu display
	DashMenuCtrl.$inject =	 ['$http','$rootScope','$scope','$sce','$location','$routeParams', 'authService'];

	function DashMenuCtrl($http, $rootScope, $scope, $sce, $location, $routeParams, authService){
		var self = this;
		//Funciones
		//self.go = go;
		var user_metadata = authService.getUserMetadata();
		var profile = authService.getCachedProfile();

		self.user_name = profile.name;
		self.initials = profile.given_name.substring(0,1);


		$http.get('/api/url').success(function(data){
		  	self.dashboards = user_metadata.hubs[data.hub].dashboards;
			self.applications = user_metadata.hubs[data.hub].apps;
			self.appsMenu = [];

			if (self.dashboards==undefined)
				self.dashboards = [];
			if (self.applications==undefined)
				self.applications = [];

			var obj = [];
			for (var i = 0; i < self.applications.length; i++) {

				//if object size is 2 add one more and push it to the
				//array
				if (  Object.keys(obj).length >= 2) {
					obj.push(
					{ 
						name: self.applications[i].initials,
						link: self.applications[i].url,
						type: self.applications[i].type,
						description: self.applications[i].app_name
					}
					);
					self.appsMenu.push(obj);
					obj = [];
				} else {
					obj.push(
					{ 
						name: self.applications[i].initials,
						link: self.applications[i].url,
						type: self.applications[i].type,
						description: self.applications[i].app_name
					}
					);
				}
				//check if there are pending apps to push to the array
				//check limit of apps menu to two items
				if (i === self.applications.length - 1 
				    && Object.keys(obj).length !== 0 
				    && self.appsMenu.length < 2) {
					self.appsMenu.push(obj);
					obj = [];
				}
			}
			if (self.applications.length > 6) {
				self.apps = true;
			}
			self.dashMenu = [];
			var obj = [];

			for (var i = 0; i < self.dashboards.length; i++) {
			
				//if object size is 2 add one more and push it to the
				//array
				if (  Object.keys(obj).length >= 2) {
					obj.push(
					{ 
						name: self.dashboards[i].initials,
						link: self.dashboards[i].type !== 'SISENSE' ? self.dashboards[i].url : '#/dashboard/'+self.dashboards[i].slug+'/'+self.dashboards[i].menu.default,
						type: self.dashboards[i].type,
						description: self.dashboards[i].name,
						status: self.dashboards[i].status
					}
					);
					self.dashMenu.push(obj);
					obj = [];
				} else {

					obj.push(
					{ 
						name: self.dashboards[i].initials,
						link: self.dashboards[i].type !== 'SISENSE' ? self.dashboards[i].url : '#/dashboard/'+self.dashboards[i].slug+'/'+self.dashboards[i].menu.default,
						type: self.dashboards[i].type,
						description: self.dashboards[i].name,
						status: self.dashboards[i].status

					}
					);
				}
				//check if there are pending apps to push to the array
				//check limit of apps menu to two items
				if (i === self.dashboards.length - 1 
				    && Object.keys(obj).length !== 0 
				    && self.dashMenu.length < 2) {
					self.dashMenu.push(obj);
					obj = [];
				}
			}
		
			if (self.dashboards.length > 6) {
				self.dash = true;
			}
			
			self.dashboards.filter(function (obj){
				if (obj.slug == $routeParams.slug){
					self.actualDashboard = $routeParams.dashboard_id;
					self.slug = obj.slug;
					self.menu = obj.menu;
					var stop = false;

					angular.forEach(self.menu.items, function(item,key){

						if( item.url == self.actualDashboard){
							item.active = true;
						}
						else{
							item.active = false;
							angular.forEach(item.subitems, function(subitem){
								subitem.active = false;
								if (subitem.url == self.actualDashboard){
									subitem.active = true;
									item.active = true;
									stop = true;
								}else if(!stop){
									item.active = false;
								}
							});
						}
					})
				}
			});
		});
	}

})();
