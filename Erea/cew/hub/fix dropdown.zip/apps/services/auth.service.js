(function () {

    'use strict';
  
    angular
      .module('ereaHubApp')
      .service('authService', authService);
  
    authService.$inject = ['$location', 'angularAuth0', '$timeout','$q'];
  
    function authService($location, angularAuth0, $timeout, $q) {
  
      function login(conn) {
        var deferred = $q.defer();

        if(conn.connection=='Username-Password-Authentication'){
          angularAuth0.client.login({
            realm: conn.connection,
            username: conn.username,
            password: conn.password,
          }, function(err, authResult) {
            if (err) {
              deferred.reject(err);
            }
            if (authResult && authResult.idToken) {
              setSession(authResult);
              $location.path('/');
              deferred.resolve(authResult);
            }
          });
        }
        else if(conn.connection=='google-oauth2'){
          angularAuth0.authorize({
            connection: 'google-oauth2'
          }, function(err) {
            deferred.reject(err);
          });
        }

        return deferred.promise;
      }
      
      function handleAuthentication() {
        angularAuth0.parseHash(function(err, authResult) {
          if (authResult && authResult.accessToken && authResult.idToken) {
            setSession(authResult);
            $location.path('/');
          } else if (err) {
            $timeout(function() {
              $location.path('/');
            });
            console.log(err);
            alert('Error: ' + err.error + '. Check the console for further details.');
          }
        });
      }
  
      function setSession(authResult) {
        // Set the time that the access token will expire at
        let expiresAt = JSON.stringify((36000 * 1000) + new Date().getTime());
        localStorage.setItem('access_token', authResult.accessToken);
        localStorage.setItem('id_token', authResult.idToken);
        localStorage.setItem('expires_at', expiresAt);
      }
      
      function logout() {
        // Remove tokens and expiry time from localStorage
        localStorage.removeItem('access_token');
        localStorage.removeItem('id_token');
        localStorage.removeItem('expires_at');
        localStorage.removeItem('user_profile');
        localStorage.removeItem('user_metadata');
        $location.path('/');
      }
      
      function isAuthenticated() {
        // Check whether the current time is past the 
        // access token's expiry time
        let expiresAt = JSON.parse(localStorage.getItem('expires_at'));
        return new Date().getTime() < expiresAt;
      }

      function getProfile(cb) {
        var accessToken = localStorage.getItem('access_token');
        if (!accessToken) {
          throw new Error('Access Token must exist to fetch profile');
        }
        angularAuth0.client.userInfo(accessToken, function(err, profile) {
          if (profile) {
            setUserProfile(profile);
          }
          cb(err, profile);
        });
      }

      function setUserProfile(profile) {
        localStorage.setItem('user_profile', JSON.stringify(profile));
      }

      function getCachedProfile() {
        return JSON.parse(localStorage.getItem('user_profile'));
      }

      function setUserMetadata(userMetadata) {
        localStorage.setItem('user_metadata', JSON.stringify(userMetadata));
      }

      function getUserMetadata() {
        return JSON.parse(localStorage.getItem('user_metadata'));
}
  
      return {
        login: login,
        handleAuthentication: handleAuthentication,
        logout: logout,
        isAuthenticated: isAuthenticated,
        getProfile: getProfile,
        setUserProfile: setUserProfile,
        getCachedProfile: getCachedProfile,
        setUserMetadata: setUserMetadata,
        getUserMetadata: getUserMetadata
      }
    }
  })();
  
