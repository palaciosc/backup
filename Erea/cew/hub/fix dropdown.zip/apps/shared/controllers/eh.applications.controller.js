(function(){
	'use strict';
	//Controlador de las aplicaciones
	angular.module('ereaHubApp')
		.controller('ApplicationsCtrl', ApplicationCtrl);

	ApplicationCtrl.$inject = ['angularAuth0', '$scope', '$location'];
	function ApplicationCtrl(angularAuth0, $scope, $location) {
		$scope.auth = angularAuth0;
		$scope.applications = angularAuth0.profile.user_metadata.apps;
		//Funcion que hace valido el link para hacer el login en SISENSE
		$scope.trustSrc = function(src) {
			return $sce.trustAsResourceUrl(src);
		}
		$scope.go = function(target) {
			$location.path(target);
		}
		//Email necesario para obtener el enlace para hacer el Single Sign On.
		var email = angularAuth0.profile.email;

		var user_name = "";
		if(angularAuth0.profile.name){
			user_name = angularAuth0.profile.name;
		}else if(angularAuth0.profile.user_metadata){
			user_name = angularAuth0.profile.user_metadata.name;
		}else{
			user_name = email;
		}
		$scope.initials = angularAuth0.profile.given_name.substring(0,1);
		$scope.message = 'Hola, ' + user_name + '!';
	};
})();
