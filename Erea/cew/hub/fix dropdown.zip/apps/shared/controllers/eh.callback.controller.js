(function () {

    'use strict';
  
    angular
      .module('ereaHubApp')
      .controller('CallbackCtrl', CallbackCtrl);
  
    function CallbackCtrl() {}
  
  })();