(function(){
	'use strict';
	//Controlador del Home
	angular.module('ereaHubApp')
		.controller('MsgCtrl')
		.controller('HomeCtrl', function (authService, $rootScope, $q, $scope, $http, $sce, $location) {
			var vm = this;
			vm.auth = authService;
			vm.profile;

			if(!authService.isAuthenticated()){
				$location.path('/login');
				//authService.login();
				return;
			} else {
				console.log('Authenticated!!!');
			}

			function getProfile() {
				var deferred = $q.defer();
				if (authService.getCachedProfile()) {
					deferred.resolve(authService.getCachedProfile());
				} else {
					authService.getProfile(function(err, profile) {
						if(!err) {
							deferred.resolve(profile);
						}
					});
				}

				return deferred.promise;
			}

			function getMetadata(userId) {
				var idToken = localStorage.getItem('id_token');
				var req = {
					method: 'GET',
					url: 'https://erea.auth0.com/api/v2/users/'+ userId +'?fields=user_metadata&include_fields=true',
					headers: {
						Authorization: 'Bearer '+ idToken
					}
				}

				return $http(req);
			}

			var promise = getProfile();
			promise.then(function (profile) {
				vm.profile = profile;

				getMetadata(vm.profile.sub).then(function(res) {
					authService.setUserMetadata(res.data.user_metadata);
					$http.get('/api/url').success(function(data){
						$scope.dashboards = res.data.user_metadata.hubs[data.hub].dashboards;
						$scope.applications = res.data.user_metadata.hubs[data.hub].apps;
					
						//Funcion que hace valido el link para hacer el login en SISENSE
						$scope.trustSrc = function(src) {
							return $sce.trustAsResourceUrl(src);
						}
						$scope.go = function(target) {
							$location.path(target);
						}
						//Se obtiene la data de los dashboards.
						//Email necesario para obtener el enlace para hacer el Single Sign On.
						var email = vm.profile.email;

						var user_name = "";
							if(vm.profile.name){
								user_name = vm.profile.name;
							}else if(vm.profile.user_metadata){
								user_name = vm.profile.user_metadata.name;
						}else{
							user_name = email;
						}
						
						$scope.user_name = user_name;
						$scope.initials = vm.profile.given_name.substring(0,1);

						$scope.message = 'Hola, ' + user_name + '!';

						//Categories for home filtering
						$scope.categories = [
							{id:'1', name:"Todos los sectores"},
							{id:'2', name:"Corporativo"},
							{id:'3', name:"Retail"},
							{id:'4', name:"Centros comerciales"},
							{id:'5', name:"Auditoría"},
							{id:'6', name:"Logística"},
							{id:'7', name:"Reporte de Uso"},
							{id:'8', name:"SRV"}
						];

						$scope.selected = { value: $scope.categories[0] };

						$scope.subcategories =  [
							{id:'1', name:'Todos los departamentos', categories:['Corporativo','Retail','Centros comerciales','Auditoría','Logística','Reporte de Uso','SRV']},
							{id:'2', name:'Finanzas', categories:['Corporativo','Centros comerciales']},
							{id:'3', name:'Sectorial', categories:['Centros comerciales','Retail','Auditoría','Logística','Reporte de Uso','SRV']}
						];

				    	$scope.selectedsubcategory = { value: $scope.subcategories[0] };

						$scope.filterHasCategory = function(item){
							if($scope.selected.value.id == 1)
								return true;
							else if(item.categories.includes($scope.selected.value.name))
								return true;
							else
								return false;
						}

						$scope.filterHasSubCategory = function(item){
							if($scope.selectedsubcategory.value.id == 1)
								return true;
							else if(item.subcategories.includes($scope.selectedsubcategory.value.name))
								return true;
							else
								return false;
						}
					});
				});
			});
		});
})();
