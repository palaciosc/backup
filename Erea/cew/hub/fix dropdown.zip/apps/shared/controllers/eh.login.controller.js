(function(){
	'use strict';
	//Controlador del Home
	angular.module('ereaHubApp')
	.controller('LoginCtrl', EHLoginCtrl);

	EHLoginCtrl.$inject = ['$scope', 'authService','$location', 'store', '$timeout'];
	function EHLoginCtrl($scope, authService, $location, store, $timeout) {
	  $scope.user = '';
	  $scope.pass = '';
	  $scope.email= '';

	  if(authService.isAuthenticated()){
	    $location.path('/');
	    return;
	  }

	  function onLoginSuccess(profile, token) {
	    if(ga)
	    {
	      ga('set', 'userId', profile.user_id); //Se envia el user_id a google analytics.
	    }
	    $scope.message = '';
	    store.set('profile', profile);
	    store.set('token', token);
	    $location.path('/');
	    $scope.loading = false;
	  }

	  function onLoginFailed() {
	    ($scope);
	    $scope.message.text = '';
	    $scope.errorMessage.text = 'Credenciales inválidas';
	    $scope.loading = false;
	  }

	  $scope.reset = function() {
	    authService.reset({
	      email: 'hello@bye.com',
	      password: 'hello',
	      connection: 'Username-Password-Authentication'
	    });
	  };

	  $scope.submit = function () {
	    $scope.message.text = 'loading...';
	    $scope.loading = true;

	    var promise = authService.login(
	      {
	      connection: 'Username-Password-Authentication',
	      username: $scope.user,
	        password: $scope.pass
	      }
	    );
	    promise.then(
	    	function (authResult){
	    		$scope.errorMessage.text = '';
	    	},
	    	onLoginFailed
	    );
	  };

	  $scope.doGoogleAuthWithPopup = function () {

	    $scope.message = 'loading...';
	    $scope.loading = true;
		
		authService.login({
			connection: 'google-oauth2'
		});

	    // angularAuth0.popup.signin({
	    //   // popup: true,
	    //   connection: 'google-oauth2',
	    //   scope: 'openid name email'
	    // }, onLoginSuccess, onLoginFailed);
	  };

	};
})();
