
[![Angular](http://img.shields.io/badge/Angular-1.2.16-blue.svg)](http://angularjs.org)
[![Auth0](http://img.shields.io/badge/Auth0-6.7-yellow.svg)](http://auth0.org)
[![Angular Route](http://img.shields.io/badge/Angular Route-1.2.16-orange.svg)](http://angularjs.org)
[![CM](http://img.shields.io/badge/CM-2.0.0-lightgrey.svg)](http://angularjs.org)
[![LA](http://img.shields.io/badge/LA-1.0.9-lightgrey.svg)](http://angularjs.org)
[![OIE](http://img.shields.io/badge/OIE-1.2.13-lightgrey.svg)](http://angularjs.org)
[![HR](http://img.shields.io/badge/HR-1.1.9-lightgrey.svg)](http://angularjs.org)
[![EM](http://img.shields.io/badge/EM-1.1.2-lightgrey.svg)](http://angularjs.org)
[![OB](http://img.shields.io/badge/OB-1.1.13-lightgrey.svg)](http://angularjs.org)
[![SQ](http://img.shields.io/badge/SQ-1.1.9-lightgrey.svg)](http://angularjs.org)

# Erea Hub

Erea hub applications

1. Collection Management
2. Loan Amortization
3. Other Income And Expenses

## Running app
In order to run the apps

```sh
npm install
npm start
```

Configure Environment variable for API HOST

Create file .env with API_HOST = (insert here api host)


and point your browser to [http://localhost:3000/](http://localhost:3000).

#Dependencies used

1. [NgDialog](https://github.com/likeastore/ngDialog)
2. [Auto Complete](https://github.com/ghiden/angucomplete-alt)
3. [Custom/Optimized Tree Grid](https://github.com/ghiden/angucomplete-alt)
4. [DotENV](https://www.npmjs.com/package/dotenv)

#Versionamiento Erea Hub
    Niveles: #. #. #
        1. Proyecto de producción (cambia con cada deploy al cliente) [RELEASE CANDIDATE]
        2. Desarrollo por sprint (cambia con cada sprint completado)  [BETA]
        3. Historias de usuario (cambia con cada historia de usuario completada) [ALPHA]
    Manejo de Repositorios.
        1. Branch por applicación
        2. Branch de Development (merge de las aplicaciones)
            2.1 Se hace deploy en el dev environment aws
        3. Branch master (merge de brach dev)
            3.1 Se hace deploy en el prod aws
            3.2 Se hace un deploy manual para estar consciente
            
