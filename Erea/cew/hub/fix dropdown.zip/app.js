var dotenv = require('dotenv').config()
var express = require('express');
var app = express();
var jwt = require('jwt-simple');
var url = require('url');


var bodyParser = require('body-parser');
app.use( bodyParser.json() );       // to support JSON-encoded bodies
app.use(bodyParser.urlencoded({     // to support URL-encoded bodies
  extended: true
})); 


app.use(express.static('.', { maxAge: 4 * 60 * 60 * 1000 /* 2hrs */ }))

/*
*   Descripcion:Funcion del API que te permite obtener un enlace con los parametros necesarios
*               para realizar un Single Sign On.
*   Parametros: Email para utenticarse en SISENSE, si el usuario no existe creara un 
*               usuario como viewer por defecto.
*/

app.get("/api/url", function(req, res) {
    var response = {
    	"env":process.env.API_HOST,
    	"hub":process.env.hub
	};
    res.json(response);
});

app.set('port', process.env.PORT || 3000);
module.exports = app;

