var ereaHubApp = angular.module('ereaHubApp', [
  'ngCookies', 'auth0.auth0', 'ngRoute', 'angular-storage', 
  'angular-jwt','ereaHubHeader','ehDashboard'

]);

config.$inject = [
  '$routeProvider',
  '$locationProvider',
  '$httpProvider',
  'angularAuth0Provider',
  'jwtOptionsProvider',
  'jwtInterceptorProvider'
];

ereaHubApp.config(function ($routeProvider, angularAuth0Provider, $httpProvider,
  $locationProvider, jwtOptionsProvider, jwtInterceptorProvider) {
  
  jwtOptionsProvider.config({
     tokenGetter: function(){
        return localStorage.getItem('id_token');
      },
      whiteListedDomains: ['localhost', 'cew.ereahub.com', 'data.ereaxp.com'],
      unauthenticatedRedirectPath: '/login'
  });

  $routeProvider
  .when('/logout',  {
    templateUrl: 'apps/shared/layouts/logout.html',
    controller: 'LogoutCtrl'
  })
  .when('/login',   {
    templateUrl: 'apps/shared/layouts/login.html',
    controller: 'LoginCtrl'
  })
  .when('/callback',  {
    templateUrl: 'apps/shared/layouts/callback.html',
    controller: 'CallbackCtrl'
  })
  .when('/', {
    templateUrl: 'apps/shared/layouts/home.html',
    controller: 'HomeCtrl',
    /* isAuthenticated will prevent user access to forbidden routes */
    requiresLogin: true
  })
  .when('/dashboards', {
    templateUrl: 'apps/shared/layouts/dashboards.html',
    controller: 'DashboardsCtrl',
    /* isAuthenticated will prevent user access to forbidden routes */
    requiresLogin: true
  })
  .when('/applications', {
    templateUrl: 'apps/shared/layouts/applications.html',
    controller: 'ApplicationsCtrl',
    /* isAuthenticated will prevent user access to forbidden routes */
    requiresLogin: true
  })

  $locationProvider.hashPrefix('');

  angularAuth0Provider.init({
    domain: 'erea.auth0.com',
    clientID: 'kwBAayuYVAnH9bjLMdiaZE2ahqDCfZww',
    responseType: 'token id_token',
    audience: 'https://erea.auth0.com/userinfo',
    redirectUri: 'http://cew.ereahub.com/#/login',
    scope: 'openid profile email'
  });

  jwtInterceptorProvider.tokenGetter = function(store) {
    return store.get('token');
  };

  // Add a simple interceptor that will fetch all requests and add the jwt token to its authorization header.
  // NOTE: in case you are calling APIs which expect a token signed with a different secret, you might
  // want to check the delegation-token example
  $httpProvider.interceptors.push('jwtInterceptor');

}).run(function($rootScope, authService, store, jwtHelper, $location, $q, $http) {

  function getProfile() {
    var deferred = $q.defer();
    if (authService.getCachedProfile()) {
      deferred.resolve(authService.getCachedProfile());
    } else {
      authService.getProfile(function(err, profile) {
        if(!err) {
          deferred.resolve(profile);
        }
      });
    }
    return deferred.promise;
  }

	authService.handleAuthentication();

  $rootScope.$on('$viewContentLoaded', function(event) {
    //Se envia en todo momento la información del usuario y la pagina a la que cambio.
    if(ga && authService.isAuthenticated()){
      var promise = getProfile();
      promise.then(function (profile) {
        ga('set', 'userId', profile.sub);
        ga('set', 'page', $location.url());
        ga('send', 'pageview');
      });
    }
  });

  $rootScope.$on('$locationChangeSuccess', function(event) {
    try{
      if(authService.isAuthenticated()){
        var promise = getProfile();
        promise.then(function (profile) {
          $http.get('/api/url').success(function (data) {
            _chatlio.identify(profile.sub, {
              name: profile.name,
              email: profile.email,
              enterprise: data.hub
            });
          });
        });
      }
    }catch(err){}
  });

});
