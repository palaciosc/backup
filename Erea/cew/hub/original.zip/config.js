/****************************************************************************
* Nombre: config.js
* Descripción: Este archivo está destinado para la configuración de cada HUB
*****************************************************************************/
var config = {
	//Servicios
	idGoogleAnalytics : 'UA-102314410-3',
	idClientAuth0 : 'w7KtDpsxuYhHlq30DNhnGEnLu09DoUtV',
	idSlaask: '9b0471cd3e091b9895561dbff8981c4d',
	domain : 'erea.auth0.com',
	
	//Login
	companyName: 'CEW',
	srcLogo: 'public/images/logo.jpeg',
	helpMail: 'cew@ereaconsulting.com',
	googleAuthentication:false,
	usernamePasswordAuthentication: true,
	hub: 'cew'
};
